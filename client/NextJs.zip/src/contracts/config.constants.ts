import { z } from 'zod';

// Define the schema for your configuration using Zod
const ConfigSchema = z.object({
  IS_CLIENT: z.string().min(0, 'IS_CLIENT should be an empty string'),
  AUTH_ISSUER: z.string().min(1, 'AUTH_ISSUER is required'),
  KV_REST_API_READ_ONLY_TOKEN: z.string().min(1, 'KV_REST_API_READ_ONLY_TOKEN is required'),
  KV_REST_API_TOKEN: z.string().min(1, 'KV_REST_API_TOKEN is required'),
  KV_REST_API_URL: z.string().url('KV_REST_API_URL must be a valid URL'),
  KV_URL: z.string().url('KV_URL must be a valid URL'),
  NEXTAUTH_SECRET: z.string().min(1, 'NEXTAUTH_SECRET is required'),
  NEXTAUTH_URL: z.string().url('NEXTAUTH_URL must be a valid URL'),
  NEXT_PUBLIC_URL: z.string().url('NEXT_PUBLIC_URL must be a valid URL'),
  NEXT_PUBLIC_A11Y: z.string(),
  NODE_ENV: z.string().min(1, 'NODE_ENV is required'),
  EMAIL_HOST: z.string().min(1, 'EMAIL_HOST is required'),
  EMAIL_PORT: z.string().min(1, 'EMAIL_PORT is required'),
  EMAIL_USER: z.string().min(1, 'EMAIL_USER is required'),
  EMAIL_PASS: z.string().min(1, 'EMAIL_PASS is required'),
  EMAIL_TO: z.string().email('EMAIL_TO must be a valid email address'),
  DEFAULT_DOMAIN: z.string().min(1, 'DEFAULT_DOMAIN is required'),
  CORE_URL: z.string().url('CORE_URL must match your express server url'),
});

// Parse environment variables with Zod
const configSchema = ConfigSchema.safeParse(process.env);
const emptyConfig = {
  IS_CLIENT: true,
  AUTH_ISSUER: '',
  // DATABASE_URL: '',
  KV_REST_API_READ_ONLY_TOKEN: '',
  KV_REST_API_TOKEN: '',
  KV_REST_API_URL: '',
  KV_URL: '',
  NEXTAUTH_SECRET: '',
  NEXTAUTH_URL: '',
  NEXT_PUBLIC_URL: '',
  NEXT_PUBLIC_A11Y: '',
  NODE_ENV: process.env.NODE_ENV,
  EMAIL_HOST: '',
  EMAIL_PORT: '',
  EMAIL_USER: '',
  EMAIL_PASS: '',
  EMAIL_TO: '',
  DEFAULT_DOMAIN: '',
  CORE_URL: '',
};
if (!configSchema.success && typeof window === 'undefined') throw new Error(configSchema.error.message);
export const config = !configSchema.success ? emptyConfig : configSchema.data;
