export { AnimatedTemplate as default } from '@/components/client';
