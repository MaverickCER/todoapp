'use client';

import { Check, Delete } from '@/assets/icons';
import { Clipboard } from '@/assets/images';
import { BACKGROUND_CLASSES } from '@/contracts/tailwind.constants';
import { useTaskContext } from '@/hooks';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { useCallback } from 'react';
import { RenderJson } from '../server';
import ScrollToTopButton from './scroll-to-top-button';

export function List() {
  const t = useTranslations('list');
  const {
    taskContext: { tasks },
    setTaskContext,
  } = useTaskContext();

  const handleComplete = useCallback(async (task) => {
    await setTaskContext({ ...task, completed: !task.completed });
  }, []);

  const handleDelete = useCallback(async (task) => {
    await setTaskContext(task.id);
  }, []);

  if (!tasks || !tasks.length) {
    return (
      <section
        className='flex flex-col text-center justify-center items-center gap-3 rounded-2xl min-h-96'
        style={{ borderTop: '1px solid #333', marginTop: '24px' }}
      >
        <div>
          <Clipboard />
        </div>
        <RenderJson json={t.raw('notasks')} />
      </section>
    );
  }

  return (
    <>
      <ul style={{ marginTop: '24px' }}>
        {(tasks || []).map((task, index) => (
          <li
            key={`${task.title}${index}`}
            className={`flex space-x-3 bg-soot border-gray bg-brand-soot border-1 border-solid rounded my-3`}
          >
            <div className='flex'>
              <div className={BACKGROUND_CLASSES[task.color || 'none'] + ' w-1 min-h-full'} />
              <button
                type='button'
                onClick={() => handleComplete(task)}
                title={task.completed ? t('markincomplete') : t('markcomplete')}
                className='w-10 h-10 flex items-center justify-center rounded-full hover:opacity-50'
              >
                <div
                  className={
                    'w-5 h-5 flex items-center justify-center rounded-full svg-wrapper ' +
                    (task.completed ? 'bg-brand-purple' : 'border-2 border-brand')
                  }
                >
                  {task.completed ? <Check /> : ' '}
                </div>
              </button>
            </div>
            <Link
              href={'/edit/' + task.id}
              className={`w-full flex items-center text-left ${task.completed ? 'opacity-70' : ''}`}
              title={t('edit')}
            >
              {task.completed ? <del>{task.title}</del> : task.title}
            </Link>
            <div>
              <button
                type='button'
                onClick={() => handleDelete(task)}
                title={t('delete')}
                className='w-10 h-10 flex items-center justify-center rounded-full hover:opacity-50'
              >
                <Delete />
              </button>
            </div>
          </li>
        ))}
      </ul>
      <ScrollToTopButton />
    </>
  );
}

export default List;
