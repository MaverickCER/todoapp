'use client';

export { SessionProvider as AuthProvider } from 'next-auth/react';
