/*
  Warnings:

  - You are about to drop the column `delete_data_completed` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `delete_data_details` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `delete_data_method` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `delete_data_reason` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `delete_data_reminder` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `delete_data_requested` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `delete_data_status` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `domain` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_last_reviewed` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_advertising` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_analytics` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_functional` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_marketing` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_necessary` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_performance` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_social_media` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_cookies_of_type_third_party` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_internet_protocol_parsing` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_last_reviewed` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_via_app` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_via_email` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_via_mail` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_via_phone` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_via_sms` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_newsletter_via_web_push` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_last_reviewed` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_via_app` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_via_email` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_via_mail` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_via_phone` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_via_sms` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_notifications_via_web_push` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_policies_date` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_policies_method` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_policies_url` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_sell_data_to_third_parties` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_share_data_with_third_parties` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_last_reviewed` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_via_app` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_via_email` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_via_mail` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_via_phone` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_via_sms` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_transactions_via_web_push` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_consenting_to_user_agent_parsing` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_mfa_enabled` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `is_new_profile` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `notified_of_changes_to_policy` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `profile_token_ttl` on the `profiles` table. All the data in the column will be lost.
  - You are about to drop the column `refresh_token_revoked` on the `profiles` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[email]` on the table `profiles` will be added. If there are existing duplicate values, this will fail.
  - Made the column `language_code` on table `profiles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `is_language_ltr` on table `profiles` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX `profiles_email_domain_key` ON `profiles`;

-- AlterTable
ALTER TABLE `profiles` DROP COLUMN `delete_data_completed`,
    DROP COLUMN `delete_data_details`,
    DROP COLUMN `delete_data_method`,
    DROP COLUMN `delete_data_reason`,
    DROP COLUMN `delete_data_reminder`,
    DROP COLUMN `delete_data_requested`,
    DROP COLUMN `delete_data_status`,
    DROP COLUMN `domain`,
    DROP COLUMN `is_consenting_to_cookies_last_reviewed`,
    DROP COLUMN `is_consenting_to_cookies_of_type_advertising`,
    DROP COLUMN `is_consenting_to_cookies_of_type_analytics`,
    DROP COLUMN `is_consenting_to_cookies_of_type_functional`,
    DROP COLUMN `is_consenting_to_cookies_of_type_marketing`,
    DROP COLUMN `is_consenting_to_cookies_of_type_necessary`,
    DROP COLUMN `is_consenting_to_cookies_of_type_performance`,
    DROP COLUMN `is_consenting_to_cookies_of_type_social_media`,
    DROP COLUMN `is_consenting_to_cookies_of_type_third_party`,
    DROP COLUMN `is_consenting_to_internet_protocol_parsing`,
    DROP COLUMN `is_consenting_to_newsletter_last_reviewed`,
    DROP COLUMN `is_consenting_to_newsletter_via_app`,
    DROP COLUMN `is_consenting_to_newsletter_via_email`,
    DROP COLUMN `is_consenting_to_newsletter_via_mail`,
    DROP COLUMN `is_consenting_to_newsletter_via_phone`,
    DROP COLUMN `is_consenting_to_newsletter_via_sms`,
    DROP COLUMN `is_consenting_to_newsletter_via_web_push`,
    DROP COLUMN `is_consenting_to_notifications_last_reviewed`,
    DROP COLUMN `is_consenting_to_notifications_via_app`,
    DROP COLUMN `is_consenting_to_notifications_via_email`,
    DROP COLUMN `is_consenting_to_notifications_via_mail`,
    DROP COLUMN `is_consenting_to_notifications_via_phone`,
    DROP COLUMN `is_consenting_to_notifications_via_sms`,
    DROP COLUMN `is_consenting_to_notifications_via_web_push`,
    DROP COLUMN `is_consenting_to_policies_date`,
    DROP COLUMN `is_consenting_to_policies_method`,
    DROP COLUMN `is_consenting_to_policies_url`,
    DROP COLUMN `is_consenting_to_sell_data_to_third_parties`,
    DROP COLUMN `is_consenting_to_share_data_with_third_parties`,
    DROP COLUMN `is_consenting_to_transactions_last_reviewed`,
    DROP COLUMN `is_consenting_to_transactions_via_app`,
    DROP COLUMN `is_consenting_to_transactions_via_email`,
    DROP COLUMN `is_consenting_to_transactions_via_mail`,
    DROP COLUMN `is_consenting_to_transactions_via_phone`,
    DROP COLUMN `is_consenting_to_transactions_via_sms`,
    DROP COLUMN `is_consenting_to_transactions_via_web_push`,
    DROP COLUMN `is_consenting_to_user_agent_parsing`,
    DROP COLUMN `is_mfa_enabled`,
    DROP COLUMN `is_new_profile`,
    DROP COLUMN `notified_of_changes_to_policy`,
    DROP COLUMN `profile_token_ttl`,
    DROP COLUMN `refresh_token_revoked`,
    ADD COLUMN `banned_by` INTEGER NULL,
    MODIFY `language_code` VARCHAR(191) NOT NULL DEFAULT 'en',
    MODIFY `is_language_ltr` BOOLEAN NOT NULL DEFAULT true;

-- CreateTable
CREATE TABLE `tasks` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `title` VARCHAR(191) NOT NULL,
    `color` VARCHAR(191) NOT NULL,
    `completed` BOOLEAN NOT NULL DEFAULT false,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,
    `profile_id` INTEGER NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateIndex
CREATE UNIQUE INDEX `profiles_email_key` ON `profiles`(`email`);

-- AddForeignKey
ALTER TABLE `tasks` ADD CONSTRAINT `tasks_profile_id_fkey` FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
