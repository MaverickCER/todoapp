'use client';

export function InfoSkeleton() {
  return (
    <div className='flex justify-between items-center w-full'>
      <span className='flex items-center'>
        <div className='bg-zinc-200 rounded-full px-3 justify-center items-center'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
        &nbsp;
        <div className='bg-zinc-700 rounded-full px-3 justify-center items-center'>&nbsp;&nbsp;</div>
      </span>
      <span className='flex items-center'>
        <div className='bg-zinc-200 rounded-full px-3 justify-center items-center'>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
        &nbsp;
        <div className='bg-zinc-700 rounded-full px-3 justify-center items-center'>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
      </span>
    </div>
  );
}

export default InfoSkeleton;
