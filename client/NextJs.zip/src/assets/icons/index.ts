export { default as Back } from './back.svg?react';
export { default as Check } from './check.svg?react';
export { default as Delete } from './delete.svg?react';
export { default as Language } from './language.svg?react';
export { default as Plus } from './plus.svg?react';
